/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function send_example_to_js(): number;
export function receive_example_from_js(a: number): void;
export function replace_all_stream(a: number, b: number): void;
export function __wbindgen_malloc(a: number, b: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number, d: number): number;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_free(a: number, b: number, c: number): void;

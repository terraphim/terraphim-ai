# Terraphim Context search extension to allow quick search of selected text from the browser in Terraphim and add content to logseq


Originally  inspired [SearchTool]("https://github.com/anurag-ks/SearchTool.git")


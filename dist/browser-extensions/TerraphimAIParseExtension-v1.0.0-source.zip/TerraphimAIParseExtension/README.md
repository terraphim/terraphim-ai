# Popup With Content Script

This is the source code for my Medium blog post, "How to Use A Content Script with a Popup In Your Chrome Extension".

[Upgrade your free Medium membership](https://matt-croak.medium.com/membership) and receive unlimited, ad-free, stories from thousands of writers on a wide variety of publications. This is an affiliate link and a portion of your membership helps me be rewarded for the content I create.

You can also [subscribe via email](https://matt-croak.medium.com/subscribe) and get notified whenever I post something new!

Connect with me on socials, or pay an invoice [here](https://linktr.ee/mattcroak)!